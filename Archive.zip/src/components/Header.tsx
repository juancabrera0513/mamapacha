import React, { useState } from "react";
import { useCart } from "@/context/CartContext";

export const Header: React.FC = () => {
  const [open, setOpen] = useState(false);
  const { count, total } = useCart();

  const NavLink = ({ href, children }: { href: string; children: React.ReactNode }) => (
    <a href={href} className="text-sm font-semibold hover:text-primary">
      {children}
    </a>
  );

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur border-b border-zinc-100">
      <div className="container-xl flex items-center justify-between h-16">
        <a href="#" className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-xl bg-primary"></div>
          <span className="font-display text-xl font-extrabold tracking-tight">Mama Pacha</span>
        </a>

        <nav className="hidden md:flex items-center gap-8">
          <NavLink href="#shop">Shop</NavLink>
          <NavLink href="#featured">Featured</NavLink>
          <NavLink href="#story">Our Story</NavLink>
          <NavLink href="#testimonials">Reviews</NavLink>
          <NavLink href="#contact">Contact</NavLink>
        </nav>

        <div className="flex items-center gap-3">
          <a href="#shop" className="btn btn-outline hidden sm:inline-flex">Shop Spices</a>
          <a href="#contact" className="btn btn-primary hidden lg:inline-flex">Catering & Contact</a>
          <button
            className="relative rounded-xl px-3 py-2 border border-zinc-200 hover:border-primary"
            aria-label="Open cart"
            onClick={() => alert(`Demo cart — items: ${count}, total: $${total.toFixed(2)}`)}
          >
            <span className="text-sm font-semibold">Cart</span>
            {count > 0 && (
              <span className="absolute -top-2 -right-2 text-xs bg-primary text-white rounded-full px-2 py-0.5">
                {count}
              </span>
            )}
          </button>

          <button className="md:hidden p-2" onClick={() => setOpen(!open)} aria-label="Menu">
            <svg width="24" height="24" fill="none" stroke="currentColor"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
          </button>
        </div>
      </div>

      {open && (
        <div className="md:hidden border-t border-zinc-100">
          <div className="container-xl py-4 flex flex-col gap-4">
            <a className="font-semibold" href="#shop" onClick={() => setOpen(false)}>Shop</a>
            <a className="font-semibold" href="#featured" onClick={() => setOpen(false)}>Featured</a>
            <a className="font-semibold" href="#story" onClick={() => setOpen(false)}>Our Story</a>
            <a className="font-semibold" href="#testimonials" onClick={() => setOpen(false)}>Reviews</a>
            <a className="font-semibold" href="#contact" onClick={() => setOpen(false)}>Contact</a>
          </div>
        </div>
      )}
    </header>
  );
};
