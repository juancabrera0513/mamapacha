import React from "react";
import { SOCIAL } from "@/data/site";

export const Footer: React.FC = () => {
  return (
    <footer className="mt-20 bg-dark text-zinc-200">
      <div className="container-xl py-12 grid md:grid-cols-3 gap-10">
        <div>
          <h4 className="font-display text-xl mb-3">Mama Pacha Spices & Catering</h4>
          <p className="text-sm/6 text-zinc-400">
            Traditional flavors made with natural ingredients. Salt-free, preservative-free blends and Puerto Rican catering.
          </p>
        </div>
        <div>
          <h5 className="font-semibold mb-3">Links</h5>
          <ul className="space-y-2 text-sm">
            <li><a className="hover:text-white" href="#shop">Shop</a></li>
            <li><a className="hover:text-white" href="#story">Our Story</a></li>
            <li><a className="hover:text-white" href="#contact">Contact</a></li>
            <li><a className="hover:text-white" href="#policies">Policies</a></li>
          </ul>
        </div>
        <div>
          <h5 className="font-semibold mb-3">Follow us</h5>
          <div className="flex gap-4">
            <a className="hover:text-white" href={SOCIAL.instagram} target="_blank">Instagram</a>
            <a className="hover:text-white" href={SOCIAL.facebook} target="_blank">Facebook</a>
            <a className="hover:text-white" href={SOCIAL.tiktok} target="_blank">TikTok</a>
          </div>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="container-xl py-6 text-xs text-zinc-400 flex items-center justify-between">
          <span>© 2020–2025. All rights reserved.</span>
          <a id="policies" className="hover:text-white" href="#policies">Site Policies</a>
        </div>
      </div>
    </footer>
  );
};
