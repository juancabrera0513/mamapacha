export type Product = {
    id: string;
    name: string;
    description: string;
    price: number;
    size: string;
    image: string;
    badge?: string;
  };
  
  export const PRODUCTS: Product[] = [
    {
      id: "adobo",
      name: "Adobo (No Salt)",
      description: "Puerto Rican–inspired spice blend. No salt, no preservatives.",
      price: 10,
      size: "4 oz",
      image:
        "https://images.squarespace-cdn.com/content/v1/66918196e0f8ef08219905b0/da323ee2-9f36-4954-af80-5ec680e09d88/Packaging_Adobo+2.png?format=1500w", // <- sin espacio inicial
      badge: "Best Seller",
    },
    {
      id: "sazon",
      name: "Sazón (All Natural)",
      description:
        "All-natural color and flavor for your dishes—made to enhance, not overpower.",
      price: 10,
      size: "4 oz",
      image:
        "https://images.squarespace-cdn.com/content/v1/66918196e0f8ef08219905b0/435a0f0b-b2bf-4241-99ab-d1c1ab093b40/Packaging_Sazon+2.png?format=1500w",
    },
  ];
  
  // ✅ Press logos reales
  export const PRESS_LOGOS = [
    {
      alt: "The Royale Food and Spirits",
      src: "https://images.squarespace-cdn.com/content/v1/66918196e0f8ef08219905b0/2501a672-13f7-4afd-9710-a45bc860b5fa/MAMA_PACHA-_The+Royale+Food+and+Spirits.png?format=750w",
    },
    {
      alt: "STL TV",
      src: "https://images.squarespace-cdn.com/content/v1/66918196e0f8ef08219905b0/8fe761cc-b9b7-4263-aebe-482ba71fcf33/MAMA_PACHA-_STL+Tv.png?format=750w",
    },
    {
      alt: "FOX 2",
      src: "https://images.squarespace-cdn.com/content/v1/66918196e0f8ef08219905b0/42fabde0-9b62-4262-bb93-7524688e635b/MAMA_PACHA-_Fox+2.png?format=500w",
    },
    {
      alt: "En Contacto Magazine STL",
      src: "https://images.squarespace-cdn.com/content/v1/66918196e0f8ef08219905b0/ae8a469b-befd-4566-8c66-27af92c77f14/MAMA_PACHA-_En+Contacto+Magazine+STL.png?format=750w",
    },
    {
      alt: "Hispanic Festival, Inc. STL",
      src: "https://images.squarespace-cdn.com/content/v1/66918196e0f8ef08219905b0/8b2a1844-dda9-4c2f-aadf-afe79816f0ef/MAMA_PACHA-_Hispanic+Festival%2C+Inc.+STL.png?format=750w",
    },
  ];
  
  // 👇 Para mantener compatibilidad si algún componente aún importa SUPPORTERS
  export const SUPPORTERS = PRESS_LOGOS;
  
  export const TESTIMONIALS = [
    {
      quote:
        "I tried the empanadas at a festival—every bite tasted like home. Highly recommended.",
      author: "Yasmen D.",
    },
    {
      quote:
        "Salt-free, preservative-free blends helped me cook healthier without losing flavor.",
      author: "Elizabeth R.",
    },
    {
      quote:
        "The sazón arrived super fresh. I used half right away and saved the rest. Delicious!",
      author: "Natasha N.",
    },
  ];
  
  export const SOCIAL = {
    instagram: "https://www.instagram.com/mamapachasabor/",
    facebook: "https://www.facebook.com/mamapachasabor",
    tiktok: "https://www.tiktok.com/@mamapachasabor",
  };
  