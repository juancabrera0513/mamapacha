import React from "react";

export const Hero: React.FC = () => {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 -z-10 bg-[url('https://images.squarespace-cdn.com/content/v1/66918196e0f8ef08219905b0/380de986-55cc-402d-9b59-a899e701aeeb/MAMAPACHA-hero.jpg?format=2500w')] bg-cover bg-center" />
      <div className="absolute inset-0 -z-10 bg-black/40" />

      <div className="container-xl py-24 sm:py-28 md:py-36 text-white">
        <span className="inline-block rounded-full bg-white/10 px-4 py-1.5 text-sm font-semibold tracking-wide">
          From Puerto Rican traditions — with love
        </span>
        <h1 className="mt-6 font-display text-4xl sm:text-5xl md:text-6xl font-extrabold max-w-3xl">
          From our kitchen to your table
        </h1>
        <p className="mt-4 text-lg max-w-2xl text-white/90">
          Salt-free, preservative-free spice blends and Puerto Rican catering for your events.
        </p>

        <div className="mt-8 flex flex-col sm:flex-row gap-3">
          <a href="#shop" className="btn btn-primary">Shop Spices</a>
          <a href="#contact" className="btn btn-outline backdrop-blur">Catering & Contact</a>
        </div>

        <div className="mt-10 grid grid-cols-2 sm:grid-cols-4 gap-3 opacity-90">
          {["adobo", "sazon", "empanadas", "pastelillos"].map((tag) => (
            <div key={tag} className="rounded-xl bg-white/10 px-3 py-2 text-sm font-semibold capitalize">
              {tag}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
