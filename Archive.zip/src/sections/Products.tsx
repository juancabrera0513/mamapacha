import React from "react";
import { PRODUCTS } from "@/data/site";
import { useCart } from "@/context/CartContext";

export const Products: React.FC = () => {
  const { add } = useCart();

  return (
    <section id="shop" className="container-xl py-16">
      <header className="text-center mb-10">
        <h2 className="font-display text-3xl sm:text-4xl font-extrabold">Shop Spices</h2>
        <p className="text-zinc-600 mt-2">
          Adobo and Sazón mixes — 100% natural, inspired by tradition.
        </p>
      </header>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {PRODUCTS.map((p) => (
          <article key={p.id} className="card overflow-hidden group">
            <div className="aspect-[4/3] overflow-hidden">
              <img src={p.image} alt={p.name} className="h-full w-full object-cover group-hover:scale-105 transition"/>
            </div>
            <div className="p-5">
              <div className="flex items-start justify-between gap-3">
                <h3 className="font-semibold text-lg">{p.name}</h3>
                {p.badge && (
                  <span className="text-xs bg-accent/20 text-primary px-2 py-1 rounded-full">{p.badge}</span>
                )}
              </div>
              <p className="text-sm text-zinc-600 mt-2">{p.description}</p>
              <div className="mt-4 flex items-center justify-between">
                <span className="font-semibold">
                  ${p.price.toFixed(2)} <span className="text-zinc-500 text-xs">({p.size})</span>
                </span>
                <button className="btn btn-primary" onClick={() => add(p)}>Add to cart</button>
              </div>
            </div>
          </article>
        ))}
      </div>

      <p className="text-center text-xs text-zinc-500 mt-6">
        * Demo cart (no payments processed).
      </p>
    </section>
  );
};
