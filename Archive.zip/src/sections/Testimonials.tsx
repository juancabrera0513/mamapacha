import React from "react";
import { TESTIMONIALS } from "@/data/site";

export const Testimonials: React.FC = () => {
  return (
    <section id="testimonials" className="bg-zinc-50">
      <div className="container-xl py-16">
        <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-center">Lo que dicen</h2>
        <div className="mt-10 grid md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t, i) => (
            <figure key={i} className="card p-6">
              <blockquote className="text-zinc-700">“{t.quote}”</blockquote>
              <figcaption className="mt-4 text-sm font-semibold text-zinc-600">— {t.author}</figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
};
