import React, { useState } from "react";
import { SOCIAL } from "@/data/site";

export const Contact: React.FC = () => {
  const [sent, setSent] = useState(false);

  const socials = [
    { name: "Instagram", href: SOCIAL.instagram },
    { name: "Facebook", href: SOCIAL.facebook },
    { name: "TikTok", href: SOCIAL.tiktok },
  ];

  return (
    <section id="contact" className="container-xl py-20">
      <div className="grid lg:grid-cols-2 gap-12 items-start">
        <div>
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold">Let’s connect</h2>
          <p className="mt-3 text-zinc-700">
            For general questions, partnerships, or press, send us a message. You can also reach us on social.
          </p>
          <div className="mt-6 flex gap-4 flex-wrap">
            {socials.map((s) => (
              <a
                key={s.name}
                className="btn btn-outline"
                href={s.href}
                target="_blank"
                rel="noreferrer"
                aria-label={s.name}
              >
                {s.name}
              </a>
            ))}
          </div>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            setSent(true);
          }}
          className="card p-6"
        >
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-semibold">First Name</label>
              <input
                className="mt-1 w-full rounded-xl border border-zinc-200 px-3 py-2 outline-none focus:ring-2 focus:ring-primary"
                required
              />
            </div>
            <div>
              <label className="text-sm font-semibold">Last Name</label>
              <input
                className="mt-1 w-full rounded-xl border border-zinc-200 px-3 py-2 outline-none focus:ring-2 focus:ring-primary"
                required
              />
            </div>
          </div>
          <div className="mt-4">
            <label className="text-sm font-semibold">Email</label>
            <input
              type="email"
              className="mt-1 w-full rounded-xl border border-zinc-200 px-3 py-2 outline-none focus:ring-2 focus:ring-primary"
              required
            />
          </div>
          <div className="mt-4">
            <label className="text-sm font-semibold">Subject</label>
            <input className="mt-1 w-full rounded-xl border border-zinc-200 px-3 py-2 outline-none focus:ring-2 focus:ring-primary" />
          </div>
          <div className="mt-4">
            <label className="text-sm font-semibold">Message</label>
            <textarea
              rows={5}
              className="mt-1 w-full rounded-xl border border-zinc-200 px-3 py-2 outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          <button className="btn btn-primary mt-5 w-full" type="submit">
            Send
          </button>
          {sent && <p className="text-green-700 text-sm mt-3">Thanks! We’ll get back to you soon.</p>}
        </form>
      </div>
    </section>
  );
};
