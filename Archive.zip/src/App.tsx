import React from "react";
import { Header } from "./components/Header";
import { Footer } from "./components/Footer";
import { Hero } from "./sections/Hero";
import { Products } from "./sections/Products";
// import { Featured } from "./sections/Featured";
import { Story } from "./sections/Story";
import { Supporters } from "./sections/Supporters";
import { Testimonials } from "./sections/Testimonials";
import { Contact } from "./sections/Contact";
import { CartProvider } from "./context/CartContext";

export default function App() {
  return (
    <CartProvider>
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1">
          <Hero />
          <Products />
          {/* <Featured /> */}
          <Story />
          <Supporters />
          <Testimonials />
          <Contact />
        </main>
        <Footer />
      </div>
    </CartProvider>
  );
}
